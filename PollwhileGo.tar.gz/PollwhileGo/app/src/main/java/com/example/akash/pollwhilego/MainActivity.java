package com.example.akash.pollwhilego;

import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button result,yes,no,back,next;
    TextView prodetail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result=(Button)findViewById(R.id.result);
        yes=(Button)findViewById(R.id.yes);
        no=(Button)findViewById(R.id.no);
        back=(Button)findViewById(R.id.back);
        next=(Button)findViewById(R.id.next);
        prodetail=(TextView)findViewById(R.id.prodetail);

        result.setOnClickListener(this);
        yes.setOnClickListener(this);
        no.setOnClickListener(this);
        back.setOnClickListener(this);
        next.setOnClickListener(this);


    }

    @Override
    public void onClick(View view)
    {
        if (view == result)
        {

            if ()
            {
                showMessage("Error", "No project found");
                return;
            }
            else()
            {
                StringBuffer buffer = new StringBuffer();
                while ()
                {
                    buffer.append("Project Name:" + c.getString(0) + "\n");
                    buffer.append("Accepted:" + c.getString(1) + "\n");
                    buffer.append("Rejected" + c.getString(2) + "\n");
                }
                showMessage("Project Details", buffer.toString());
            }
        }
        if (view == yes)
        {

        }
        if (view == no)
        {

        }
        if (view == back)
        {

        }
        if (view == next)
        {

        }

    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
