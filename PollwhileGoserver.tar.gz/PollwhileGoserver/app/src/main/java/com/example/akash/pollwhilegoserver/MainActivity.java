package com.example.akash.pollwhilegoserver;

import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;



public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    EditText projectname;
    Button pollstart, pollresult;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        projectname = (EditText) findViewById(R.id.projectname);
        pollresult = (Button) findViewById(R.id.pollresult);
        pollstart = (Button) findViewById(R.id.pollstart);

        pollstart.setOnClickListener(this);
        pollresult.setOnClickListener(this);



    }

    @Override
    public void onClick(View view) {

        FirebaseDatabase  db= FirebaseDatabase.getInstance();
        DatabaseReference myref= db.getReference("poll");

        Projectdetails ob = new Projectdetails();

        if (view == pollstart)
        {
            if (projectname.getText().toString().trim().length() == 0)
            {
                showMessage("Error", "Please enter project details");
                return;
            }

            ob.setName(projectname.getText().toString());
            ob.setAccepted(0);
            ob.setRejected(0);
            myref.setValue(ob);
            showMessage("Success", "Project added to database");
            clearText();
        }

        if (view == pollresult)
        {

            if ()
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer = new StringBuffer();
            while ()
            {
                buffer.append("Project Name:" + ob.name + "\n");
                buffer.append("Accepted:" + ob.accepted + "\n");
                buffer.append("Reject:" + ob.rejected + "\n");
            }
            showMessage("Projectdetails", buffer.toString());
        }

    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText()
    {
        projectname.setText("");
    }
}

