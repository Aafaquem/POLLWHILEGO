package com.example.akash.pollwhilegoserver;

import android.text.Editable;

public class Projectdetails {

    String name;

    int accepted,rejected;

    public void setName(String name) {
        this.name = name;
    }

    public void setAccepted(int accepted) {
        this.accepted = accepted;
    }

    public void setRejected(int rejected) {
        this.rejected = rejected;
    }
}
